# Integrante C · Wishlist, carrito, pedidos y administración

Guía rápida de lo que se agregó al backend, cómo probarlo y qué hay que acordar con el equipo.

## 1. Qué hay y dónde

| Requisito | Dónde está |
|---|---|
| Wishlist (guardar/quitar, sin duplicados, 3 estados, mover a carrito) | `wishlist/` |
| Carrito por usuario con validaciones y resumen | `cart/` |
| Checkout simulado + pedido con precio aplicado | `order/service/OrderService` |
| Comprobante PDF | `order/service/ReceiptPdfService` |
| Correo con el PDF (sin duplicar el pedido si falla) | `order/service/ReceiptMailService` |
| Administración y reportes | `admin/` |
| Auditoría y ubicaciones | `audit/` + `admin/controller/AdminAuditController` |

**Decisiones clave**

- **Sin duplicados:** wishlist y carrito tienen restricción única `(usuario, producto)` en la base de datos, además de la validación en código.
- **Precios siempre del servidor:** el cliente nunca envía precios ni totales.
- **Checkout = una transacción:** bloquea el carrito, descuenta stock con un `UPDATE` atómico (nunca queda en negativo), guarda el pedido con el precio vigente de cada línea y vacía el carrito. Si algo falla, no queda nada a medias. El doble clic no duplica el pedido porque la segunda solicitud espera y encuentra el carrito vacío.
- **Correo fuera de la transacción:** el pedido ya está confirmado cuando se intenta enviar. Si el correo falla, el pedido queda intacto con `emailStatus = FAILED` y se reenvía con `POST /api/orders/{id}/resend-receipt`, sin crear otro pedido. Si el correo del usuario no está verificado, queda en `PENDING` y no se envía nada.
- **IP ≠ GPS:** la auditoría guarda siempre la IP. Las coordenadas solo se guardan si el navegador las envía (permiso del usuario) y quedan marcadas como `GPS`. Los eventos con solo IP no traen coordenadas.
- **Cancelar un pedido devuelve el stock.** Flujo permitido: `PAID → SHIPPED → DELIVERED`, y `PAID → CANCELLED`.

## 2. Archivos del código de tu compañero que se modificaron (solo 2)

1. **`pom.xml`**: se agregaron `spring-boot-starter-mail` y `openpdf 1.3.30` (necesarios para correo y PDF).
2. **`exception/GlobalExceptionHandler.java`**: solo se *agregó* código, no se cambió nada existente.
   - Handlers para `UnauthorizedException` (401) y `ForbiddenException` (403): los necesita mi parte.
   - JSON mal formado o enum inválido, y parámetros con tipo incorrecto, ahora dan 400 (antes caían en el 500 genérico).
   - **Corrección:** el handler general convertía en 500 los errores 4xx propios de Spring (ruta inexistente, método no permitido, etc.) y no registraba nada en el log. Ahora esos conservan su código y los 500 reales se registran.

Los tests existentes de ese handler siguen siendo válidos (un `Exception` común sigue dando 500).

## 3. Puntos de integración con el resto del equipo

1. **Autenticación (pendiente del equipo).** El proyecto no tiene login/JWT todavía. Todo mi código obtiene al usuario desde **un único lugar**: `security/CurrentUserService`. Mientras tanto, con `tstyle.auth.dev-header-enabled=true` acepta el encabezado `X-User-Id` para probar. **Está apagado por defecto y debe estar apagado en producción** (cualquiera podría hacerse pasar por un admin). Cuando exista el JWT, solo hay que cambiar el cuerpo de `resolveUserId()` para leer el usuario del contexto de seguridad; ningún controlador ni servicio cambia.
2. **Producto.** No existía catálogo, así que se creó `product/model/Product` **mínima** (id, name, price, stock, active) y su repositorio con dos consultas de stock. Si el compañero del catálogo tiene su propia entidad, se reemplaza conservando esos campos y las dos consultas `decreaseStock` / `increaseStock`.
3. **Auditoría.** No existía tabla de auditoría, así que se creó una mínima (`audit/`). Si otro integrante ya tiene la suya (por ejemplo, para eventos de login), hay que dejar una sola y apuntar `AuditService` a ella.
4. **Base de datos.** Se asume `spring.jpa.hibernate.ddl-auto=update` (las tablas nuevas son `tstyle_products`, `tstyle_cart_items`, `tstyle_wishlist_items`, `tstyle_orders`, `tstyle_order_items`, `tstyle_audit_logs`). Confirmar con el equipo.
5. **Verificación de correo.** No hay endpoint para verificar correos; mientras tanto se marca a mano en la base (ver sección 5).
6. **CORS** para el frontend Angular no está configurado en el proyecto base; afecta a todos los endpoints, no solo a estos.

## 4. Configuración (`application.properties`, que está en `.gitignore`)

```properties
# Correo (usar variables de entorno; con Gmail, una "contraseña de aplicación")
spring.mail.host=smtp.gmail.com
spring.mail.port=587
spring.mail.username=${MAIL_USERNAME}
spring.mail.password=${MAIL_PASSWORD}
spring.mail.properties.mail.smtp.auth=true
spring.mail.properties.mail.smtp.starttls.enable=true
spring.mail.properties.mail.smtp.connectiontimeout=5000
spring.mail.properties.mail.smtp.timeout=5000
spring.mail.properties.mail.smtp.writetimeout=5000

# Opcional: remitente (por defecto usa spring.mail.username)
# tstyle.mail.from=no-reply@tstyle.com

# SOLO DESARROLLO: permite identificarse con el encabezado X-User-Id
tstyle.auth.dev-header-enabled=true
```

Si no se configura `spring.mail.host`, la aplicación arranca igual y los pedidos quedan con `emailStatus = FAILED` ("servidor de correo no configurado").
Si el backend queda detrás de un proxy, configurar `server.forward-headers-strategy=framework` para que la IP de auditoría sea la del cliente real.

## 5. Cómo probarlo

Con la aplicación corriendo, crear datos de prueba (registrar usuarios con `POST /api/users/register` y luego en MySQL):

```sql
INSERT INTO tstyle_products (name, price, stock, active) VALUES
  ('Camisa básica', 50000.00, 20, 1),
  ('Pantalón jean', 120000.00, 15, 1),
  ('Chaqueta', 250000.00, 5, 1);

UPDATE tstyle_users SET email_verified = 1 WHERE email = 'cliente@correo.com';
UPDATE tstyle_users SET role = 'ADMIN', email_verified = 1 WHERE email = 'admin@correo.com';
```

Flujo de ejemplo (cliente con id 1):

```bash
H='-H "X-User-Id: 1" -H "Content-Type: application/json"'
curl -X PUT  localhost:8080/api/wishlist/1 $H -d '{"status":"LIKE"}'
curl -X POST localhost:8080/api/wishlist/1/move-to-cart $H
curl -X POST localhost:8080/api/cart/items $H -d '{"productId":2,"quantity":3}'
curl         localhost:8080/api/cart $H
curl -X POST localhost:8080/api/orders/checkout $H -d '{}'
curl -OJ     localhost:8080/api/orders/1/receipt $H          # descarga el PDF
```

**Prueba de "el correo falla y el pedido no se duplica":** hacer el checkout sin SMTP configurado → responde 201 con `emailStatus: "FAILED"`. Configurar el SMTP y llamar `POST /api/orders/1/resend-receipt` → pasa a `SENT` y la lista de pedidos sigue teniendo uno solo.

## 6. Endpoints

**Usuario autenticado**

| Método | Ruta | Descripción |
|---|---|---|
| GET | `/api/wishlist?status=` | Lista (filtro opcional `WATCH_LATER`, `LIKE`, `DISLIKE`) |
| PUT | `/api/wishlist/{productId}` | Guarda o cambia estado (body opcional `{"status":"LIKE"}`; por defecto `WATCH_LATER`) |
| DELETE | `/api/wishlist/{productId}` | Quita |
| POST | `/api/wishlist/{productId}/move-to-cart` | Mueve al carrito (body opcional `{"quantity":2}`) |
| GET | `/api/cart` | Resumen del carrito |
| POST | `/api/cart/items` | Agrega `{productId, quantity}` (suma si ya existe; máx. 10 por producto) |
| PUT | `/api/cart/items/{productId}` | Cambia cantidad |
| DELETE | `/api/cart/items/{productId}` · `/api/cart` | Quita una línea · vacía el carrito |
| POST | `/api/orders/checkout` | Checkout simulado. Body opcional con `latitude`, `longitude`, `accuracyMeters` |
| GET | `/api/orders` · `/api/orders/{id}` | Mis pedidos · detalle |
| GET | `/api/orders/{id}/receipt` | Descarga el PDF |
| POST | `/api/orders/{id}/resend-receipt` | Reintenta el correo (también lo puede usar un admin) |

**Administrador** (rol `ADMIN`)

| Método | Ruta | Descripción |
|---|---|---|
| GET | `/api/admin/orders` | Filtros: `status`, `emailStatus` (p. ej. `FAILED`), `userId`, `from`, `to` (yyyy-MM-dd), `page`, `size` |
| GET | `/api/admin/orders/{id}` | Detalle, con el motivo del último fallo de correo |
| PATCH | `/api/admin/orders/{id}/status` | `{"status":"SHIPPED"}` |
| GET | `/api/admin/reports/sales` | Ventas del periodo con desglose diario (por defecto últimos 30 días) |
| GET | `/api/admin/reports/top-products` | Más vendidos (`from`, `to`, `limit`) |
| GET | `/api/admin/reports/wishlist` | Más guardados en wishlists (`limit`) |
| GET | `/api/admin/audit` | Auditoría con filtros `userId`, `action`, `from`, `to` |
| GET | `/api/admin/audit/locations` | Solo eventos con coordenadas, para dibujar marcadores |

Errores: mismo formato `ErrorResponse` del equipo (400, 401, 403, 404, 409, 500).

## 7. Frontend: ubicación y Google Maps

- Pedir la ubicación con `navigator.geolocation.getCurrentPosition()` **solo después de mostrar un aviso de uso de datos y que el usuario acepte**; si la rechaza, el checkout se envía sin coordenadas.
- Google Maps **no descubre** ubicaciones: solo dibuja las que ya están guardadas. El panel de admin debe consumir `/api/admin/audit/locations` y pintar un marcador por cada evento (`latitude`, `longitude`; `accuracyMeters` sirve para dibujar un círculo de precisión).
- Convertir una IP en una ciudad aproximada requeriría una base como GeoLite2 o un servicio externo; **no está incluido** y por eso los eventos solo con IP no aparecen en el mapa.

## 8. Por confirmar con el equipo

- Qué reportes se acordaron exactamente (los 3 incluidos son un punto de partida).
- El límite de 10 unidades por producto (`cart/dto/CartLimits`).
- Si un usuario con correo sin verificar debería poder comprar (hoy puede; el comprobante queda `PENDING`).
- Exportación a CSV de reportes: no incluida.
- El frontend debe deshabilitar el botón mientras una petición está en curso; si se repite el checkout, el segundo intento responde "El carrito está vacío" en lugar de duplicar.

## 9. Pruebas automáticas

Se agregaron tests unitarios (JUnit 5 + Mockito) y de controladores (`@WebMvcTest`) en el mismo estilo del proyecto: carrito, wishlist, checkout, PDF, correo (incluido el caso de fallo SMTP), administración, usuario actual y los nuevos handlers. Ejecutar con `./mvnw test`.
